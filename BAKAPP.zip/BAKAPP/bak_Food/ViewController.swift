//
//  ViewController.swift
//  bak_Food
//
//  Created by Rey De Reyes on 14/11/17.
//  Copyright © 2017 Rey De Reyes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

