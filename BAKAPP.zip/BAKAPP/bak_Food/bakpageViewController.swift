//
//  bakpageViewController.swift
//  bak_Food
//
//  Created by Vanessa Paola Alvarado on 27/11/17.
//  Copyright © 2017 Rey De Reyes. All rights reserved.
//

import UIKit
import WebKit


class bakpageViewController: UIViewController {
    @IBOutlet weak var webview: WKWebView!
    
    override func loadView() {
        if let link = URL(string: "https://www.bakfood.com") { UIApplication.shared.open(link) }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

