//
//  Perros_ViewController.swift
//  bak_Food
//
//  Created by Rey De Reyes on 15/11/17.
//  Copyright © 2017 Rey De Reyes. All rights reserved.
//


//

import UIKit


class Perros_ViewController: UIViewController {

    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    @IBAction func bulldog_Frances(_ sender: Any) {
        
        let texto = "🐶: ¡Guau hola! soy un Bulldog francés, soy una mascota muy cariñosa y sociable🐾"
        performSegue(withIdentifier: "goToText", sender: texto)
        
    }
    
    @IBAction func bulldog_ingles(_ sender: Any) {
        
        let texto = "🐶: ¡Guau hola! soy un Bulldog inglés, soy fiel a mis dueños y me caracterizo por mi porte🐾"
        
        performSegue(withIdentifier: "goToText", sender: texto)
        

    }
    
    
    
    @IBAction func chihuahua(_ sender: UIButton) {
        let texto = "🐶:¡Guau hola!¿Sabías que a los chihuahuas nos consdieran como la raza de perro más antigua del continente americano?🐾"
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    
    @IBAction func colly(_ sender: UIButton) {
        let texto = "🐶: ¡Guau que gusto verte por aquí! yo soy un Collie🐾, soy extremadamente activo e inteligente🔍"
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    @IBAction func goldenRetriever(_ sender: UIButton) {
        let texto = "🐶: ¡Guau hola! yo soy un Golden retriever 🐾, me gusta que me valoren por mi inteligencia y lealtad hacía mis dueños"
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    @IBAction func ñabrador(_ sender: UIButton) {
        let texto = "🐶: ¡Guau hola! soy un perro Labrador🐾, me dicen que soy muy gentil, inteligente, enérgico y bondadoso. ¿Tu qué opinas amo?"
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    
    @IBAction func pastorAleman(_ sender: UIButton) {
        
        let texto = "🐶: ¡Guau hola! soy un Pastor alemán🐾, mi raza se caracteriza por nobleza, abnegación y fidelidad para con sus dueños."
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    @IBAction func puddle(_ sender: UIButton) {
        let texto = "🐩: ¡Guau hola! yo soy un French poodle🐾, también me dicen caniche. Soy un compañero demasiado leal y cariñoso. ¡No olvides sacarme a pasear que soy bien curioso!"
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    @IBAction func snuzer(_ sender: UIButton) {
        let texto = "🐶: ¡Guau hola! soy un Schnauzer🐾, el significado de mi nombre es perro de hocico barbudo. ¡Puntos por mi elegancia!"

        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    @IBAction func yorki(_ sender: UIButton) {
        let texto = "🐶: ¡Guau hola! soy un Yorkshire terrier🐾 mi pelo es fino y sedoso, es uno de mis mayores atractivos, aunque requiere una gran cantidad de cuidados."
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    
    @IBAction func salchicha(_ sender: UIButton) {
        
        let texto = "🐶: ¡Guau hola! soy un perro Teckel,también me dicen perro salchicha🐾 soy muy alegre y estoy dispuesto a dar amor 24/7."
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    @IBAction func pomeranian(_ sender: UIButton) {
        
        let texto = "🐶: ¡Guau hola! soy un Pomerania 🐾, no olvides cepillarme los dientes al menos una vez por semana, y luego toma una foto de nosotros para instagram."
        
        performSegue(withIdentifier: "goToText", sender: texto)

    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "goToText"{
            if let destination = segue.destination as? DatosViewController{
                destination.datos = sender as! String
            }
        }
        
    }
    
    
    
    

}
