//
//  DatosViewController.swift
//  bak_Food
//
//  Created by Rey De Reyes on 20/11/17.
//  Copyright © 2017 Rey De Reyes. All rights reserved.
//

import UIKit

class DatosViewController: UIViewController {

    @IBOutlet weak var descripcion: UITextView!
    @IBOutlet weak var peso: UITextField!
    @IBOutlet weak var porcion: UILabel!
    
    @IBOutlet weak var TOTAL: UILabel!
    var datos = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        descripcion.text = "\(datos)"
        peso.text = String (0)
        
       
        // Do any additional setup after loading the view.
    }

   
    
    @IBAction func cachorroAadulto(_ sender: UISwitch) {
        
        let peso_mascota = Float(peso.text!)
        
        if (sender.isOn) == true { //Adulto
            
              porcion.text = String(describing: (peso_mascota! * 0.35)*1000)
            TOTAL.text = String(describing: (peso_mascota! * 0.35)*1000*14)

           }else{
            
            porcion.text = String(describing: ((peso_mascota! * 0.10)*1000))
            TOTAL.text = String(describing: (peso_mascota! * 0.35)*1000*28)
            
        }
    
    }
    
    
    
  
    
    @IBAction func goBack(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
        
    }
    
    
        
    }
    

